#! /bin/sh

export PATH="/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/local/games:/usr/games:/opt/ali/dma/bin:/opt/ali/gof/test"
export GST_PLUGIN_PATH="/opt/ali/gof/usr/lib/gstreamer-0.10"
export GST_REGISTRY="/tmp/gst/gst_registry.bin"
export LD_LIBRARY_PATH="/opt/ali/gof/lib:/opt/ali/gof/usr/lib:/opt/ali/dma/lib"

mkdir -p /nmp/NmpObject/
chmod -R 777 /nmp

count=`ps | grep servicemanager | wc -l`
if [ "$count" -gt "0" ]; then
    echo "servicemanager exist"
else
    servicemanager &
fi

sleep 2s

killall -9 axxplay_sample

axxplay_sample &

#start dlna

killall -9 dlna_service
killall -9 dlnaservice_sample
killall -9 systemservice

dlnaservice_sample -a &


